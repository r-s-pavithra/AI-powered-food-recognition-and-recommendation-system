import streamlit as st

st.set_page_config(page_title="Chatbot", page_icon="💬")
st.title("💬 AI Assistant")
st.info("🚧 AI Chatbot will be implemented in Week 5")
