from typing import Optional
from backend.config import GEMINI_API_KEY

try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

class ChatbotService:
    """Service for AI chatbot using Google Gemini"""
    
    def __init__(self):
        if GEMINI_AVAILABLE and GEMINI_API_KEY:
            genai.configure(api_key=GEMINI_API_KEY)
            self.model = genai.GenerativeModel('gemini-pro')
        else:
            self.model = None
    
    def get_response(self, user_message: str, context: Optional[str] = None) -> str:
        """
        Get AI response for user message
        """
        if not self.model:
            return "AI Chatbot is not configured. Please add GEMINI_API_KEY to .env file."
        
        try:
            # Build prompt with context
            prompt = f"""You are a helpful food and cooking assistant. 
            Help users with recipes, food storage tips, and cooking questions.
            
            User question: {user_message}
            """
            
            if context:
                prompt += f"\n\nContext: {context}"
            
            response = self.model.generate_content(prompt)
            return response.text
        
        except Exception as e:
            return f"Error getting AI response: {str(e)}"
