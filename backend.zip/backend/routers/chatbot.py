from fastapi import APIRouter, Depends
from pydantic import BaseModel
from backend.routers.auth import get_current_user
from backend.models.user import User

router = APIRouter(prefix="/api/chatbot", tags=["Chatbot"])

class ChatRequest(BaseModel):
    message: str

@router.post("/chat")
def chat(
    request: ChatRequest,
    current_user: User = Depends(get_current_user)
):
    """Chat with AI assistant"""
    return {
        "message": "AI Chatbot coming in Week 5",
        "response": "Hello! I'm your food assistant. This feature will be available soon."
    }
